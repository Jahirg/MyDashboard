# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_mainHtkRuC.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1072, 776)
        MainWindow.setStyleSheet(u"background-color: transparent;\n"
"border-radius: 10px;")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setStyleSheet(u"background-color: transparent;\n"
"border-radius: 10px;")
        self.horizontalLayout_2 = QHBoxLayout(self.centralwidget)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u"background-color: rgb(48, 64, 80);\n"
"border-radius: 10px;")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(4, 4, 4, 4)
        self.left_menu = QFrame(self.frame)
        self.left_menu.setObjectName(u"left_menu")
        self.left_menu.setMinimumSize(QSize(44, 40))
        self.left_menu.setMaximumSize(QSize(40, 16777215))
        self.left_menu.setStyleSheet(u"background-color: rgb(32, 48, 64);")
        self.left_menu.setFrameShape(QFrame.StyledPanel)
        self.left_menu.setFrameShadow(QFrame.Raised)
        self.verticalLayout = QVBoxLayout(self.left_menu)
        self.verticalLayout.setSpacing(5)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 5, 0, 5)
        self.top_log = QFrame(self.left_menu)
        self.top_log.setObjectName(u"top_log")
        self.top_log.setMinimumSize(QSize(40, 40))
        self.top_log.setMaximumSize(QSize(40, 40))
        self.top_log.setFrameShape(QFrame.StyledPanel)
        self.top_log.setFrameShadow(QFrame.Raised)
        self.top_logo_layout = QHBoxLayout(self.top_log)
        self.top_logo_layout.setSpacing(5)
        self.top_logo_layout.setObjectName(u"top_logo_layout")
        self.top_logo_layout.setContentsMargins(5, 5, 5, 5)
        self.btn_menuCom = QPushButton(self.top_log)
        self.btn_menuCom.setObjectName(u"btn_menuCom")
        self.btn_menuCom.setStyleSheet(u"background-color: rgb(170, 170, 170);\n"
"border-radius: 3px;")
        icon = QIcon()
        icon.addFile(u"icons_svg/cil-hamburger-menu.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_menuCom.setIcon(icon)
        self.btn_menuCom.setIconSize(QSize(32, 32))

        self.top_logo_layout.addWidget(self.btn_menuCom)


        self.verticalLayout.addWidget(self.top_log)

        self.top_menus = QFrame(self.left_menu)
        self.top_menus.setObjectName(u"top_menus")
        self.top_menus.setMinimumSize(QSize(40, 40))
        self.top_menus.setMaximumSize(QSize(40, 16536))
        self.top_menus.setFrameShape(QFrame.StyledPanel)
        self.top_menus.setFrameShadow(QFrame.Raised)
        self.top_menus_layout = QVBoxLayout(self.top_menus)
        self.top_menus_layout.setSpacing(5)
        self.top_menus_layout.setObjectName(u"top_menus_layout")
        self.top_menus_layout.setContentsMargins(0, 5, 0, 5)

        self.verticalLayout.addWidget(self.top_menus)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.bottom_menus = QFrame(self.left_menu)
        self.bottom_menus.setObjectName(u"bottom_menus")
        self.bottom_menus.setMinimumSize(QSize(40, 40))
        self.bottom_menus.setMaximumSize(QSize(40, 16535))
        self.bottom_menus.setFrameShape(QFrame.StyledPanel)
        self.bottom_menus.setFrameShadow(QFrame.Raised)
        self.bottom_menus_layout = QVBoxLayout(self.bottom_menus)
        self.bottom_menus_layout.setSpacing(5)
        self.bottom_menus_layout.setObjectName(u"bottom_menus_layout")
        self.bottom_menus_layout.setContentsMargins(0, 5, 0, 5)

        self.verticalLayout.addWidget(self.bottom_menus)


        self.horizontalLayout_3.addWidget(self.left_menu)

        self.frame_body = QFrame(self.frame)
        self.frame_body.setObjectName(u"frame_body")
        self.frame_body.setStyleSheet(u"border-radius: 0px;")
        self.frame_body.setFrameShape(QFrame.StyledPanel)
        self.frame_body.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame_body)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.title_bar = QFrame(self.frame_body)
        self.title_bar.setObjectName(u"title_bar")
        self.title_bar.setMinimumSize(QSize(0, 40))
        self.title_bar.setMaximumSize(QSize(16777215, 40))
        self.title_bar.setStyleSheet(u"background-color: rgb(32, 48, 64);")
        self.title_bar.setFrameShape(QFrame.StyledPanel)
        self.title_bar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.title_bar)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(-1, 0, -1, 0)
        self.frame_icontitle = QFrame(self.title_bar)
        self.frame_icontitle.setObjectName(u"frame_icontitle")
        self.frame_icontitle.setMinimumSize(QSize(40, 0))
        self.frame_icontitle.setMaximumSize(QSize(40, 16777215))
        self.frame_icontitle.setFrameShape(QFrame.StyledPanel)
        self.frame_icontitle.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_6 = QHBoxLayout(self.frame_icontitle)
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.label_2 = QLabel(self.frame_icontitle)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(40, 40))
        self.label_2.setMaximumSize(QSize(40, 40))
        self.label_2.setPixmap(QPixmap(u"icons_svg/chip.png"))
        self.label_2.setScaledContents(True)

        self.horizontalLayout_6.addWidget(self.label_2)


        self.horizontalLayout_4.addWidget(self.frame_icontitle)

        self.frame_8 = QFrame(self.title_bar)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setMinimumSize(QSize(0, 32))
        self.frame_8.setMaximumSize(QSize(16777215, 32))
        self.frame_8.setFrameShape(QFrame.StyledPanel)
        self.frame_8.setFrameShadow(QFrame.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame_8)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(self.frame_8)
        self.label.setObjectName(u"label")
        font = QFont()
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(240, 240, 240);")

        self.verticalLayout_3.addWidget(self.label)


        self.horizontalLayout_4.addWidget(self.frame_8)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_3)

        self.title_extra_btns = QFrame(self.title_bar)
        self.title_extra_btns.setObjectName(u"title_extra_btns")
        self.title_extra_btns.setMinimumSize(QSize(40, 0))
        self.title_extra_btns.setFrameShape(QFrame.StyledPanel)
        self.title_extra_btns.setFrameShadow(QFrame.Raised)
        self.title_extra_btns_layout = QHBoxLayout(self.title_extra_btns)
        self.title_extra_btns_layout.setSpacing(4)
        self.title_extra_btns_layout.setObjectName(u"title_extra_btns_layout")
        self.title_extra_btns_layout.setContentsMargins(0, 0, 0, 0)

        self.horizontalLayout_4.addWidget(self.title_extra_btns)

        self.frame_btnswindow = QFrame(self.title_bar)
        self.frame_btnswindow.setObjectName(u"frame_btnswindow")
        self.frame_btnswindow.setMinimumSize(QSize(100, 32))
        self.frame_btnswindow.setMaximumSize(QSize(100, 32))
        self.frame_btnswindow.setFrameShape(QFrame.StyledPanel)
        self.frame_btnswindow.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.frame_btnswindow)
        self.horizontalLayout_5.setSpacing(6)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(4, 0, 4, 0)
        self.btn_minize = QPushButton(self.frame_btnswindow)
        self.btn_minize.setObjectName(u"btn_minize")
        self.btn_minize.setMinimumSize(QSize(0, 24))
        self.btn_minize.setMaximumSize(QSize(16777215, 24))
        self.btn_minize.setStyleSheet(u"background-color: rgba(0, 255, 0, 180);\n"
"border-radius: 5px;")
        icon1 = QIcon()
        icon1.addFile(u"icons_svg/cil-window-minimize.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_minize.setIcon(icon1)

        self.horizontalLayout_5.addWidget(self.btn_minize)

        self.btn_restore = QPushButton(self.frame_btnswindow)
        self.btn_restore.setObjectName(u"btn_restore")
        self.btn_restore.setMinimumSize(QSize(0, 24))
        self.btn_restore.setMaximumSize(QSize(16777215, 24))
        self.btn_restore.setStyleSheet(u"background-color: rgba(255, 165, 0, 240);\n"
"border-radius: 5px;")
        icon2 = QIcon()
        icon2.addFile(u"icons_svg/cil-window-maximize.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_restore.setIcon(icon2)

        self.horizontalLayout_5.addWidget(self.btn_restore)

        self.btn_close = QPushButton(self.frame_btnswindow)
        self.btn_close.setObjectName(u"btn_close")
        self.btn_close.setMinimumSize(QSize(0, 24))
        self.btn_close.setMaximumSize(QSize(16777215, 24))
        self.btn_close.setStyleSheet(u"background-color: rgba(255, 64, 0, 240);\n"
"border-radius: 5px;")
        icon3 = QIcon()
        icon3.addFile(u"icons_svg/cil-x.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_close.setIcon(icon3)

        self.horizontalLayout_5.addWidget(self.btn_close)


        self.horizontalLayout_4.addWidget(self.frame_btnswindow)


        self.verticalLayout_2.addWidget(self.title_bar)

        self.frame_data = QFrame(self.frame_body)
        self.frame_data.setObjectName(u"frame_data")
        self.frame_data.setMinimumSize(QSize(0, 25))
        self.frame_data.setMaximumSize(QSize(16777215, 25))
        self.frame_data.setFrameShape(QFrame.StyledPanel)
        self.frame_data.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_8 = QHBoxLayout(self.frame_data)
        self.horizontalLayout_8.setSpacing(0)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(-1, 0, -1, 0)
        self.label_subtitle = QLabel(self.frame_data)
        self.label_subtitle.setObjectName(u"label_subtitle")
        self.label_subtitle.setMinimumSize(QSize(120, 0))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_subtitle.setFont(font1)
        self.label_subtitle.setStyleSheet(u"color: rgb(200, 200, 200);")

        self.horizontalLayout_8.addWidget(self.label_subtitle)

        self.horizontalSpacer = QSpacerItem(501, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_8.addItem(self.horizontalSpacer)

        self.label_fecha = QLabel(self.frame_data)
        self.label_fecha.setObjectName(u"label_fecha")
        self.label_fecha.setMinimumSize(QSize(90, 0))
        font2 = QFont()
        font2.setPointSize(10)
        self.label_fecha.setFont(font2)
        self.label_fecha.setStyleSheet(u"color: rgb(200, 200, 200);")

        self.horizontalLayout_8.addWidget(self.label_fecha)

        self.label_page = QLabel(self.frame_data)
        self.label_page.setObjectName(u"label_page")
        self.label_page.setMinimumSize(QSize(90, 0))
        self.label_page.setFont(font1)
        self.label_page.setStyleSheet(u"color: rgb(200, 200, 200);")
        self.label_page.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.horizontalLayout_8.addWidget(self.label_page)


        self.verticalLayout_2.addWidget(self.frame_data)

        self.frame_pages = QFrame(self.frame_body)
        self.frame_pages.setObjectName(u"frame_pages")
        self.frame_pages.setStyleSheet(u"background-color: rgb(64, 80, 96);")
        self.frame_pages.setFrameShape(QFrame.StyledPanel)
        self.frame_pages.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_7 = QHBoxLayout(self.frame_pages)
        self.horizontalLayout_7.setSpacing(0)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.extra_LeftBox = QFrame(self.frame_pages)
        self.extra_LeftBox.setObjectName(u"extra_LeftBox")
        self.extra_LeftBox.setMinimumSize(QSize(0, 0))
        self.extra_LeftBox.setFrameShape(QFrame.StyledPanel)
        self.extra_LeftBox.setFrameShadow(QFrame.Raised)
        self.frame_7 = QFrame(self.extra_LeftBox)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setGeometry(QRect(10, 20, 220, 271))
        self.frame_7.setMinimumSize(QSize(220, 0))
        self.frame_7.setMaximumSize(QSize(220, 16777215))
        self.frame_7.setStyleSheet(u"background-color: rgb(48, 64, 80);\n"
"border-radius: 10px;")
        self.frame_7.setFrameShape(QFrame.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.frame_7)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label_8 = QLabel(self.frame_7)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font1)
        self.label_8.setStyleSheet(u"color: rgb(200, 200, 200);")

        self.verticalLayout_4.addWidget(self.label_8)

        self.verticalSpacer_13 = QSpacerItem(20, 68, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer_13)


        self.horizontalLayout_7.addWidget(self.extra_LeftBox)

        self.app_pages = QStackedWidget(self.frame_pages)
        self.app_pages.setObjectName(u"app_pages")
        self.app_pages.setStyleSheet(u"background-color: rgba(255, 0, 0,40);")
        self.wellcome = QWidget()
        self.wellcome.setObjectName(u"wellcome")
        self.horizontalLayout_11 = QHBoxLayout(self.wellcome)
        self.horizontalLayout_11.setSpacing(0)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.label_6 = QLabel(self.wellcome)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setPixmap(QPixmap(u"icons_svg/wellcome.png"))
        self.label_6.setScaledContents(True)
        self.label_6.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.label_6)

        self.app_pages.addWidget(self.wellcome)
        self.page_1 = QWidget()
        self.page_1.setObjectName(u"page_1")
        self.page_1.setStyleSheet(u"background-color: rgba(0, 100, 165,80);")
        self.horizontalLayout_12 = QHBoxLayout(self.page_1)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.label_7 = QLabel(self.page_1)
        self.label_7.setObjectName(u"label_7")
        font3 = QFont()
        font3.setPointSize(30)
        font3.setBold(True)
        font3.setWeight(75)
        self.label_7.setFont(font3)
        self.label_7.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_12.addWidget(self.label_7)

        self.app_pages.addWidget(self.page_1)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.page_2.setStyleSheet(u"background-color: rgba(128, 180, 128,80);")
        self.verticalLayout_6 = QVBoxLayout(self.page_2)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalSpacer_4 = QSpacerItem(20, 135, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_6.addItem(self.verticalSpacer_4)

        self.label_5 = QLabel(self.page_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font3)
        self.label_5.setAlignment(Qt.AlignCenter)

        self.verticalLayout_6.addWidget(self.label_5)

        self.verticalSpacer_8 = QSpacerItem(20, 135, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_6.addItem(self.verticalSpacer_8)

        self.app_pages.addWidget(self.page_2)
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.page_3.setStyleSheet(u"background-color: rgba(180, 128, 180,80);")
        self.verticalLayout_5 = QVBoxLayout(self.page_3)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalSpacer_2 = QSpacerItem(20, 144, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_5.addItem(self.verticalSpacer_2)

        self.label_3 = QLabel(self.page_3)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setFont(font3)
        self.label_3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_5.addWidget(self.label_3)

        self.verticalSpacer_3 = QSpacerItem(20, 144, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_5.addItem(self.verticalSpacer_3)

        self.app_pages.addWidget(self.page_3)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.page_4.setStyleSheet(u"background-color: rgba(255, 255, 0,70);")
        self.verticalLayout_7 = QVBoxLayout(self.page_4)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalSpacer_5 = QSpacerItem(20, 208, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_7.addItem(self.verticalSpacer_5)

        self.label_4 = QLabel(self.page_4)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font3)
        self.label_4.setStyleSheet(u"")
        self.label_4.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.label_4)

        self.verticalSpacer_6 = QSpacerItem(20, 208, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_7.addItem(self.verticalSpacer_6)

        self.app_pages.addWidget(self.page_4)
        self.page_5 = QWidget()
        self.page_5.setObjectName(u"page_5")
        self.page_5.setStyleSheet(u"background-color: rgba(255, 170, 0,60);")
        self.verticalLayout_8 = QVBoxLayout(self.page_5)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalSpacer_7 = QSpacerItem(20, 155, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_8.addItem(self.verticalSpacer_7)

        self.label_page1a_2 = QLabel(self.page_5)
        self.label_page1a_2.setObjectName(u"label_page1a_2")
        self.label_page1a_2.setFont(font3)
        self.label_page1a_2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_8.addWidget(self.label_page1a_2)

        self.verticalSpacer_9 = QSpacerItem(20, 155, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_8.addItem(self.verticalSpacer_9)

        self.app_pages.addWidget(self.page_5)
        self.page_6 = QWidget()
        self.page_6.setObjectName(u"page_6")
        self.verticalLayout_9 = QVBoxLayout(self.page_6)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalSpacer_12 = QSpacerItem(20, 156, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_9.addItem(self.verticalSpacer_12)

        self.label_page1a_3 = QLabel(self.page_6)
        self.label_page1a_3.setObjectName(u"label_page1a_3")
        self.label_page1a_3.setFont(font3)
        self.label_page1a_3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.label_page1a_3)

        self.verticalSpacer_11 = QSpacerItem(20, 155, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_9.addItem(self.verticalSpacer_11)

        self.app_pages.addWidget(self.page_6)

        self.horizontalLayout_7.addWidget(self.app_pages)

        self.extra_RightBox = QFrame(self.frame_pages)
        self.extra_RightBox.setObjectName(u"extra_RightBox")
        self.extra_RightBox.setMinimumSize(QSize(0, 0))
        self.extra_RightBox.setMaximumSize(QSize(16777215, 16777215))
        self.extra_RightBox.setFrameShape(QFrame.StyledPanel)
        self.extra_RightBox.setFrameShadow(QFrame.Raised)
        self.frame_4 = QFrame(self.extra_RightBox)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setGeometry(QRect(10, 100, 220, 71))
        self.frame_4.setMaximumSize(QSize(220, 16777215))
        self.frame_4.setStyleSheet(u"background-color: #102040;\n"
"border-radius:20px;")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_13 = QHBoxLayout(self.frame_4)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.label_10 = QLabel(self.frame_4)
        self.label_10.setObjectName(u"label_10")
        font4 = QFont()
        font4.setPointSize(8)
        font4.setBold(True)
        font4.setWeight(75)
        self.label_10.setFont(font4)
        self.label_10.setStyleSheet(u"color: rgb(255, 165, 0);")
        self.label_10.setWordWrap(True)

        self.horizontalLayout_13.addWidget(self.label_10)

        self.frame_5 = QFrame(self.extra_RightBox)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setGeometry(QRect(10, 180, 220, 201))
        self.frame_5.setMaximumSize(QSize(220, 16777215))
        self.frame_5.setStyleSheet(u"background-color: #102040;\n"
"border-radius:20px;")
        self.frame_5.setFrameShape(QFrame.StyledPanel)
        self.frame_5.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_15 = QHBoxLayout(self.frame_5)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.label_11 = QLabel(self.frame_5)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setFont(font4)
        self.label_11.setStyleSheet(u"color: rgb(0, 165, 255);")
        self.label_11.setWordWrap(True)

        self.horizontalLayout_15.addWidget(self.label_11)

        self.frame_3 = QFrame(self.extra_RightBox)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setGeometry(QRect(10, 10, 220, 81))
        self.frame_3.setMinimumSize(QSize(220, 0))
        self.frame_3.setMaximumSize(QSize(220, 16777215))
        self.frame_3.setStyleSheet(u"background-color: #102040;\n"
"border-radius:20px;")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_14 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.label_9 = QLabel(self.frame_3)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font4)
        self.label_9.setStyleSheet(u"color: rgb(165, 255, 0);")
        self.label_9.setWordWrap(True)

        self.horizontalLayout_14.addWidget(self.label_9)


        self.horizontalLayout_7.addWidget(self.extra_RightBox)


        self.verticalLayout_2.addWidget(self.frame_pages)

        self.frame_credits = QFrame(self.frame_body)
        self.frame_credits.setObjectName(u"frame_credits")
        self.frame_credits.setMinimumSize(QSize(0, 25))
        self.frame_credits.setMaximumSize(QSize(16777215, 25))
        self.frame_credits.setFrameShape(QFrame.StyledPanel)
        self.frame_credits.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_9 = QHBoxLayout(self.frame_credits)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(-1, 0, 0, 0)
        self.label_autor = QLabel(self.frame_credits)
        self.label_autor.setObjectName(u"label_autor")
        self.label_autor.setMinimumSize(QSize(120, 0))
        self.label_autor.setStyleSheet(u"color: rgb(200, 200, 255);")

        self.horizontalLayout_9.addWidget(self.label_autor)

        self.horizontalSpacer_2 = QSpacerItem(486, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_9.addItem(self.horizontalSpacer_2)

        self.label_time = QLabel(self.frame_credits)
        self.label_time.setObjectName(u"label_time")
        self.label_time.setMinimumSize(QSize(60, 0))
        self.label_time.setStyleSheet(u"color: rgb(200, 200, 255);")
        self.label_time.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.horizontalLayout_9.addWidget(self.label_time)

        self.label_hora = QLabel(self.frame_credits)
        self.label_hora.setObjectName(u"label_hora")
        self.label_hora.setMinimumSize(QSize(45, 0))
        self.label_hora.setStyleSheet(u"color: rgb(200, 200, 255);")

        self.horizontalLayout_9.addWidget(self.label_hora)

        self.frame_grip = QFrame(self.frame_credits)
        self.frame_grip.setObjectName(u"frame_grip")
        self.frame_grip.setMinimumSize(QSize(25, 25))
        self.frame_grip.setMaximumSize(QSize(25, 25))
        self.frame_grip.setStyleSheet(u"")
        self.frame_grip.setFrameShape(QFrame.StyledPanel)
        self.frame_grip.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_10 = QHBoxLayout(self.frame_grip)
        self.horizontalLayout_10.setSpacing(0)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setSizeConstraint(QLayout.SetFixedSize)
        self.horizontalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.pushButton = QPushButton(self.frame_grip)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(0, 0))
        self.pushButton.setMaximumSize(QSize(16777215, 16777215))
        self.pushButton.setStyleSheet(u"")
        icon4 = QIcon()
        icon4.addFile(u"icons_svg/cil-apps.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton.setIcon(icon4)
        self.pushButton.setIconSize(QSize(24, 24))

        self.horizontalLayout_10.addWidget(self.pushButton)


        self.horizontalLayout_9.addWidget(self.frame_grip, 0, Qt.AlignRight|Qt.AlignBottom)


        self.verticalLayout_2.addWidget(self.frame_credits)


        self.horizontalLayout_3.addWidget(self.frame_body)


        self.horizontalLayout.addWidget(self.frame)


        self.horizontalLayout_2.addLayout(self.horizontalLayout)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.app_pages.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.btn_menuCom.setText("")
        self.label_2.setText("")
        self.label.setText(QCoreApplication.translate("MainWindow", u"DASHBOARD CONTROL", None))
        self.btn_minize.setText("")
        self.btn_restore.setText("")
        self.btn_close.setText("")
        self.label_subtitle.setText(QCoreApplication.translate("MainWindow", u"MONITOR SYS", None))
        self.label_fecha.setText(QCoreApplication.translate("MainWindow", u"YYYY:MM:DD", None))
        self.label_page.setText(QCoreApplication.translate("MainWindow", u"WELLCOME", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"TO CUSTOMIZE", None))
        self.label_6.setText("")
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"BTN PAGE 1", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"TOP BOTTON 2", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"TOP BOTTON 3", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"FIRTS DOWN BUTTON", None))
        self.label_page1a_2.setText(QCoreApplication.translate("MainWindow", u"DOWN BUTTON 2", None))
        self.label_page1a_3.setText(QCoreApplication.translate("MainWindow", u"DOWN BUTTON 3", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Many of the tricks implemented here were contributed by \n"
"Martin Fitzpatrick\n"
"https://www.pythonguis.com/", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"Excellent analog meter.\n"
"Thank you. Stefan Holstein\n"
"https://github.com/StefanHol/AnalogGaugeWidgetPyQt\n"
"ANJAL.P \n"
"Spiral progress bar \n"
"https://github.com/anjalp/PySide2extn\n"
"Pete Alexandrou\n"
"QRoundProgressBar \n"
"https://sourceforge.net/projects/qroundprogressbar/\n"
"Tomasz Ziobrowski\n"
"Thermometer", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Design based on Wanderson Pimenta's PyBlackBox. \n"
"A super Teacher.\n"
"https://www.youtube.com/c/WandersonIsMe", None))
        self.label_autor.setText(QCoreApplication.translate("MainWindow", u"Designed by: JJGM", None))
        self.label_time.setText(QCoreApplication.translate("MainWindow", u"TIME |  ", None))
        self.label_hora.setText(QCoreApplication.translate("MainWindow", u"HH:MM", None))
        self.pushButton.setText("")
    # retranslateUi

